##------- Spark Funds, an asset management company Assignment -------------------

## Part 1
##Checkpoint 1: Data Cleaning 1
------------
##Load the two files companies.txt and rounds2.csv into two data frames
##and name them companies and rounds2 respectively.

## Loading /Importing companies.text file

companies <-read.delim("companies.txt",sep="\t",header=TRUE,comment.char = "", stringsAsFactors = FALSE)

View(companies)



## Loading / Importing rounds2.csv file
rounds2 <- read.csv("rounds2.csv")
View(rounds2)
-------------------

# 1.1.1. How many unique companies are present in rounds2?
rounds2$company_permalink <- tolower(rounds2$company_permalink)
options(max.print=1000000)
library("plyr")
length(unique(rounds2$company_permalink))
# Answer - 66368

-----------------
# 1.1.2. How many unique companies are present in companies ?
companies$permalink <- tolower(companies$permalink)
length(unique(companies$permalink))
# Answer - 66368
----------------

#1.1.3. In the companies data frame, which column can be used as the  unique key for each company? 
#Write the name of the column.

length(unique(companies$permalink))
#66368

nrow(companies)
#66368

#permalink 

# permalink can be used as Unique key for each companies as number of data obersavation for 
# companies data frame is 66368 and unique values for companies permalink is also 66368
--------------------------------------


#1.1.4. Are there any companies in the rounds2 file which are not present in companies ? Answer Y/N.

setdiff(rounds2$company_permalink,companies$permalink)
# No

# Number of Unique companies in round2 is 66368 and 66368 in companies data frame. as stated in earlier question answer
------------------------------------


# 1.1.5. Merge the two data frames so that all variables (columns) in the companies frame are added to 
#the rounds2 data frame.Name the merged frame master_frame.How many observations are present 
#in master_frame ?

  
#master_frame = merge(x=companies,y=rounds2,by.x = "permalink",by.y = "company_permalink",all.x = TRUE)

master_frame <- merge(companies,rounds2,by.x="permalink",by.y ="company_permalink")
#--Number of observation - 114949


------------------------------------
  
##Checkpoint 2: Data Cleaning 2
##master_frame
  
  ------------------------
#2.1.1. How many NA values are present in the column raised_amount_usd?
  
  
# Replacing all blank values in the master_frame with 'NA' as  a part of data cleaning
is.na(master_frame) <- master_frame == ''


sumnavalue<-sum(is.na(master_frame$raised_amount_usd))

# 19990
  
  
  
  -------------------------
# 2.1.2. What do you replace NA values of raised_amount_usd with? Enter a numeric value

  
# NA value contribute 17% on total observation so we can't ignore it.
  
  
# Find the subset of master_frame where raised_amount_usd is not NA
not_na <- subset(master_frame, is.na(master_frame$raised_amount_usd)==F)

# Find mean of raised_amount_usd for all non-na values
mean_not_na <- mean(not_na$raised_amount_usd)

# Replace NA values with the mean value of raised_amount_usd
master_frame$raised_amount_usd[which(is.na(master_frame$raised_amount_usd)==T)] <- mean_not_na
  
  
  
------------------------------------------------------
# Table 3.1
  
#Table 3.1 :Average values of investments for each of these funding types 
--------------------------------------------------------- 
  
 # unique(master_frame$funding_round_type)
#  [1] venture               seed                  undisclosed           equity_crowdfunding  
#[5] convertible_note      private_equity        debt_financing        angel                
#[9] grant                 secondary_market      post_ipo_equity       post_ipo_debt        
#[13] product_crowdfunding  non_equity_assistance
#14 Levels: angel convertible_note debt_financing equity_crowdfunding grant ... venture
  
#3.1.1. Average funding amount of venture type
  
fund_venture <- subset(master_frame, funding_round_type=="venture")

fund_venture_average <- mean(fund_venture$raised_amount_usd)
 
# 11623492.8242
---------------
 
#3.1.2. Average funding amount of angel type
 
 fund_angel <- subset(master_frame, funding_round_type=="angel")
 
 fund_angel_average<-mean(fund_angel$raised_amount_usd)
 # 2875945.5007
 ---------------------------------
#3.1.3. Average funding amount of seed type

fund_seed <- subset(master_frame, funding_round_type=="seed")
 
fund_seed_average<-mean(fund_seed$raised_amount_usd)

# 2920791.0773
-------------------------------
#3.1.4. Average funding amount of private equity type
fund_Private_equity <- subset(master_frame, funding_round_type=="private_equity")

fund_Private_equity_average<-mean(fund_Private_equity$raised_amount_usd)

# 63704338.5132
  

  ----------------------
#3.1.5. Considering that Spark Funds wants to invest between 5 to 15 million USD per 
#investment round, which investment type is the most suitable for them?
   -------------------
#5,000,000 - 15,000,000 USD Per investment
  
# Venture Type

-------------------------------------
#Part 2
#Checkpoint 4: Country Analysis
------------------
# Spark Funds wants to see the top 9 countries which have received the highest total funding 
#unique(fund_venture$country_code)


#aggdata <-aggregate(fund_venture, by=list(fund_venture$country_code,fund_venture$raised_amount_usd),FUN=sum)

aggventuresum<-aggregate(x=fund_venture$raised_amount_usd, list(country_code=fund_venture$country_code), sum)
sorted_venture <- aggventuresum[order(aggventuresum$x,decreasing = T),]
top9_venture <- sorted_venture[1:9,]

aggangelsum <- aggregate(x=fund_angel$raised_amount_usd, list(country_code=fund_angel$country_code), sum)
sorted_angel <- aggangelsum[order(aggangelsum$x,decreasing = T),]
top9_angel <- sorted_angel[1:9,]

aggseedsum <- aggregate(x=fund_seed$raised_amount_usd, list(country_code=fund_seed$country_code), sum)
sorted_seed <- aggseedsum[order(aggseedsum$x,decreasing = T),]
top9_seed <- sorted_seed[1:9,]

aggpvtequitysum <- aggregate(x=fund_Private_equity$raised_amount_usd , list(country_code=fund_Private_equity$country_code),sum)
sorted_pvtequity <- aggpvtequitysum[order(aggpvtequitysum$x,decreasing = T),]
top9_pvequity <- sorted_pvtequity[1:9,]

#english speaking

aggdatasum <- aggregate(x=master_frame$raised_amount_usd ,list(country = master_frame$country_code),sum)
sorted_aggdatasum <- aggdatasum[order(aggdatasum$x,decreasing = T),]
topeng <- sorted_aggdatasum[1:9,]

#USA
#GBR
#IND

#  Checkpoint 5: Sector Analysis1
  
#Install tidyr package
install.packages("tidyr")
library("tidyr")

#Load companies.csv file
#companies <-read.delim("companies.txt",sep="\t",header=TRUE,comment.char = "", stringsAsFactors = FALSE)

#Get the primary sector from category_list in companies
companies_primary_sector <- separate(data = master_frame, col = category_list, into = c("primary_sector"), sep = "\\|")
View(companies_primary_sector)



#Merge primary_sector column with the companies dataframe
#companies_primary_sector_merge <- merge(master_frame,companies_primary_sector,by.x = "permalink", by.y = "permalink")
#View(companies_primary_sector_merge)

#Load mapping_file
mapping_file <- read.csv("mapping_file.csv",header=TRUE,stringsAsFactors=FALSE)
View(mapping_file)

#Merge main_sector column with companies_primary_sector_merge
companies_sector_merge <- merge(companies_primary_sector,mapping_file,by.x = "primary_sector", by.y = "category_list")
View(companies_sector_merge)  

# CheckPoint 6#

#Country 1 -USA Funding Type Venture
#Country 2-GBR
#Country 3-IND


# Total number of Investments (count)
#6.1.1 -USA
D1 <- subset(companies_sector_merge,country_code=="USA" & raised_amount_usd>5000000 & raised_amount_usd < 15000000 & funding_round_type=="venture")
View(D1)
#6.1.1 -GBR
D2<-subset(companies_sector_merge,country_code=="GBR" & raised_amount_usd>5000000 & raised_amount_usd < 15000000 & funding_round_type=="venture")
View(D2)
#6.1.1 -IND
D3<-subset(companies_sector_merge,country_code=="IND" & raised_amount_usd>5000000 & raised_amount_usd < 15000000 & funding_round_type=="venture")
View(D3)

# 6.1.2.Total amount of investment (USD)
aggD1sum <- aggregate(x=D1$raised_amount_usd, list(country_code=D1$country_code), sum)
View(aggD1sum)

# 110799681072

aggD2sum <- aggregate(x=D2$raised_amount_usd, list(country_code=D2$country_code), sum)

# 7224697422

aggD3sum <- aggregate(x=D3$raised_amount_usd, list(country_code=D3$country_code), sum)

# 3894977042

# 6.1.3
#Top Sector name (no. of investment-wise)

# TOP 3 SECTOR FOR USA

TopsecNameD1 <- D1[order(D1$raised_amount_usd,decreasing = T),]

TopsecNameD1 <- TopsecNameD1[1:3,]
#
#ews, Search and Messaging
#thers
#Cleantech / Semiconductors



# TOP 3 SECTOR FOR GBR

TopsecNameD2 <- D2[order(D2$raised_amount_usd,decreasing = T),]

TopsecNameD2 <- TopsecNameD2[1:3,]

#Cleantech / Semiconductor
#Others
#Manufacturing


# TOP 3 SECTOR FOR IND

TopsecNameD3 <- D3[order(D3$raised_amount_usd,decreasing = T),]

TopsecNameD3 <- TopsecNameD3[1:3,]

#Manufacturing
#Entertainment
#Cleantech / Semiconductors


#Second Sector name (no. of investment-wise)


#Third Sector name (no. of investment-wise)


#Number of investments in top sector (3)



D1CountTopInvestment <- subset(D1,main_sector=="News, Search and Messaging")
View(D1CountTopInvestment)
1543

D2CountTopInvestment <- subset(D2,main_sector=="Cleantech / Semiconductors")
View(D2CountTopInvestment)
150

D3CountTopInvestment <- subset(D3,main_sector=="Manufacturing")
View(D3CountTopInvestment)
27

#Number of investments in second sector (4)

D1CountSecondInvestment <- subset(D1,main_sector=="Others")
View(D1CountSecondInvestment)
2876

D2CountSecondInvestment <- subset(D2,main_sector=="Others")
View(D2CountSecondInvestment)
193

D3CountSecondInvestment <- subset(D3,main_sector=="Entertainment")
View(D3CountSecondInvestment)
37

#Number of investments in third sector (5)

D1CountThirdInvestment <- subset(D1,main_sector=="Cleantech / Semiconductors")
View(D1CountThirdInvestment)
2263

D2CountThirdInvestment <- subset(D2,main_sector=="Manufacturing")
View(D2CountThirdInvestment)
48

D3CountThirdInvestment <- subset(D3,main_sector=="Cleantech / Semiconductors")
View(D3CountThirdInvestment)
23

#For point 3 (top sector count-wise), which company received the highest investment?
D1CountHighInvestment<- D1CountTopInvestment[order(D1CountTopInvestment$raised_amount_usd,decreasing = TRUE),]
D1CountHighInvestment <- D1CountHighInvestment[1:1,]
#Luminal

D2CountHighInvestment<- D2CountTopInvestment[order(D2CountTopInvestment$raised_amount_usd,decreasing = TRUE),]
D2CountHighInvestment <- D2CountHighInvestment[1:1,]
#Onyvax


D3CountHighInvestment<- D3CountTopInvestment[order(D3CountTopInvestment$raised_amount_usd,decreasing = TRUE),]
D3CountHighInvestment <- D3CountHighInvestment[1:1,]
#Skanray Technologies


#For point 4 (second best sector count-wise), which company received the highest investment?

D1CountSecondCompInvestment<- D1CountSecondInvestment[order(D1CountSecondInvestment$raised_amount_usd,decreasing = TRUE),]
D1CountSecondCompInvestment <- D1CountSecondCompInvestment[1:1,]
#SpiderCloud Wireless


D2CountSecondCompInvestment<- D2CountSecondInvestment[order(D2CountSecondInvestment$raised_amount_usd,decreasing = TRUE),]
D2CountSecondCompInvestment <- D2CountSecondCompInvestment[1:1,]

#MyOptique Group

D3CountSecondCompInvestment<- D3CountSecondInvestment[order(D3CountSecondInvestment$raised_amount_usd,decreasing = TRUE),]
D3CountSecondCompInvestment <- D3CountSecondCompInvestment[1:1,]
#Yatra



--------------------------------------

# Checkpoint 7

  # One pie chart showing the fraction of total investments (globally) in venture, seed and private equity 
  # and the average amount of investment in each funding type. 
  # This chart should make it clear that a certain funding type (FT) is best suited for Spark Funds.
  
  #Calculate total fund for venture, seed and private equity 
fund_venture_sum <- sum(fund_venture$raised_amount_usd)
fund_seed_sum <- sum(fund_seed$raised_amount_usd)
fund_Private_equity_sum <- sum(fund_Private_equity$raised_amount_usd)

# Create a dataframe with fund_type, fund_sum, percentage and average
pie_df <- data.frame(
  fund_type = c("venture", "seed", "Private_equity"),
  value = c(fund_venture_sum, fund_seed_sum, fund_Private_equity_sum)
)

pie_df$percent<- prop.table(pie_df$value)  
pie_df$average <- c(fund_venture_average, fund_seed_average, fund_Private_equity_average)

#Create pie chart
bp<- ggplot(pie_df, aes(x=factor(1), y=percent, fill=fund_type, label(average)))+ geom_bar(width = 1, stat = "identity")
bp
pie <- bp + coord_polar("y", start=0)
pie + geom_text(label = pie_df$average, size=3)



# One bar chart showing top 9 countries against the total amount of investments of funding type FT. 
# This should make the top 3 countries (Country 1, Country 2 and Country 3) very clear.  


# Aggregate of raised_amount_usd for the country
aggsum <- aggregate(x=master_frame$raised_amount_usd, list(country_code=master_frame$country_code), sum)
View(aggsum)


sorted <- aggsum[order(aggsum$x,decreasing = T),]
View(sorted)

top9 <- sorted[1:9,]
View(top9)

top9_frame <- merge(x=top9, y=master_frame, by.x = "country_code", by.y = "country_code", all.x = TRUE)
View(top9_frame)

top9_aggregate <- aggregate(x=top9_frame$raised_amount_usd, list(country_code=top9_frame$country_code, funding_round_type=top9_frame$funding_round_type), sum)
View(top9_aggregate)

ggplot(top9_aggregate, aes(country_code, x, fill = funding_round_type )) + geom_bar(stat = "identity")







# Any chart type you think is suitable: This should show the number of investments in the top 3 sectors of the top 3 countries ##
# on one chart (for the chosen investment type FT). 

master_frame_primary_sector <- separate(data = master_frame, col = category_list, into = c("primary_sector"), sep = "\\|")
View(master_frame_primary_sector)

master_frame_sector_merge <- merge(master_frame_primary_sector, mapping_file, by.x = "primary_sector", by.y = "category_list")
aggsum_master_sector_merge <- aggregate(x=master_frame_sector_merge$raised_amount_usd, list(country_code=master_frame_sector_merge$country_code), sum)
View(aggsum_master_sector_merge)

sorted <- aggsum_master_sector_merge[order(aggsum_master_sector_merge$x,decreasing = T),]
top3_master_sector <- sorted[1:9,]
View(top3_master_sector)

top3_master_sector <- sorted[1:3,]
View(top3_master_sector)

top3_master_frame <- merge(x=top3_master_sector, y=master_frame_sector_merge, by.x = "country_code", by.y = "country_code", all.x = TRUE)
View(top3_master_frame)

top3_aggregate <- aggregate(x=top3_master_frame$raised_amount_usd, list(country_code=top3_master_frame$country_code, main_sector=top3_master_frame$main_sector), sum)
View(top3_aggregate)

USA_frame <- subset(top3_aggregate,country_code=="USA")
View(USA_frame)
sorted <- USA_frame[order(USA_frame$x,decreasing = T),]
top3_USA <- sorted[1:3,]
View(top3_USA)

CHN_frame <- subset(top3_aggregate,country_code=="CHN")
sorted <- CHN_frame[order(CHN_frame$x,decreasing = T),]
top3_CHN <- sorted[1:3, ]
View(top3_CHN)
two_bind <- rbind(top3_CHN, top3_USA)
View(two_bind)

GBR_frame <- subset(top3_aggregate,country_code=="GBR")
sorted <- GBR_frame[order(GBR_frame$x,decreasing = T),]
top3_GBR <- sorted[1:3,]
three_bind <- rbind(two_bind, top3_GBR)
View(three_bind)

ggplot(three_bind, aes(country_code, x)) + geom_bar(aes(fill = main_sector), position = "dodge", stat="identity")